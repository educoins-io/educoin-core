Building Educoin
=============

See doc/build-*.md for instructions on building the various
elements of the Educoin Core reference implementation of Educoin.
