Sample configuration files for:
```
SystemD: educoind.service
Upstart: educoind.conf
OpenRC:  educoind.openrc
         educoind.openrcconf
CentOS:  educoind.init
OS X:    org.educoin.educoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
