#!/usr/bin/env bash
# use testnet settings,  if you need mainnet,  use ~/.educoin/educoind.pid file instead
export LC_ALL=C

educoin_pid=$(<~/.educoin/testnet3/educoind.pid)
sudo gdb -batch -ex "source debug.gdb" educoind ${educoin_pid}
